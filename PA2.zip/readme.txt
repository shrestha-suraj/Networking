Programming Assignment 2
Files Included:
> WebServer.java
> index.html

Program Description:
> This program creates a TCP connection from WebServer i.e. our PC to the client i.e. Browser for transfering
index.html page.

Program Running Procedure:
> Since this program has been created using Visual Studio Code
> The index.html and the WebServer.java file should be in same folder.
> Run command prompt or terminal and redirect it to the working directory (where file is present).
> Run: javac WebServer.javac
> Run: java WebServer
> In browser Run: localhost:6789/index.html
